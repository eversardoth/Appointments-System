package com.example.C35;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class C35Application {

	public static void main(String[] args) {
		SpringApplication.run(C35Application.class, args);
	}

}
