package com.example.C35;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class C35ApplicationTests {

	@Test
	void contextLoads() {
	}

}
